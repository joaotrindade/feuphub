package datatypes;

import java.util.List;
import java.util.ArrayList;

public class Curso {

	public String sigla;

	public String nome;

	public List<Cadeira> cadeiras = new ArrayList<Cadeira>();

	public Curso() {
		super();
	}

	public Curso(String curso, String sigla) {
		super();
		this.sigla = sigla;
		this.nome = curso;	
	}

	@Override
	public String toString() {
		return "Curso [sigla=" + sigla + ", nome=" + nome+"]";
	}
	
	@Override
	public boolean equals(Object obj) {
		Curso u=(Curso) obj;
		return (nome.equals(u.nome) && sigla==(u.sigla));
	}
	
	public boolean equals2(Object obj){
		Curso u=(Curso) obj;
		return (nome.equals(u.nome) && sigla==(u.sigla));
	}

}
