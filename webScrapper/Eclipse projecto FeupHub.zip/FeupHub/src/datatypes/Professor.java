package datatypes;

public class Professor {

	public String nome;
	
	public String codigo;

	public String foto;

	public Professor() {
		super();
	}

	public Professor(String codigo, String foto, String nome) {
		super();
		this.nome = nome;
		this.codigo = codigo;
		this.foto = foto;
	}

	@Override
	public String toString() {
		return "Professor [nome=" + nome + ", codigo=" + codigo + ", foto="
				+ foto + "]";
	}

	@Override
	public boolean equals(Object obj) {
		Professor u=(Professor) obj;
		return (nome.equals(u.nome) && codigo==(u.codigo) && foto==(u.foto));
	}
	
}
