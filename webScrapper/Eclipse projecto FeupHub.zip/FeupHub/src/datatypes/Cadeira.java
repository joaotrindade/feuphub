package datatypes;

import java.util.List;
import java.util.ArrayList;

public class Cadeira {
	
	public String nome;

	public String sigla;
	
	public String codigo;

	public String ano;

	public String semestre;
	
	public String ativo;

	public String opcional;

	public String ramo_nome;
	
	public Long ramo_id;
	
	public List<Professor> profs = new ArrayList<Professor>();

	public Cadeira() {
		super();
	}
	
	public Cadeira(String codigo, String nome, String sigla){
		super();
		this.nome = nome;
		this.sigla = sigla;
		this.codigo = codigo;
	}
	
	public Cadeira(String nome, String sigla, String codigo, String ano,
			String semestre, String ativo, String opcional, String ramo_nome, Long ramo_id) {
		super();
		this.nome = nome;
		this.sigla = sigla;
		this.codigo = codigo;
		this.ano = ano;
		this.semestre = semestre;
		this.ativo = ativo;
		this.opcional = opcional;
		this.ramo_nome = ramo_nome;
		this.ramo_id = ramo_id;

	}

	@Override
	public String toString() {
		return "Cadeira [nome=" + nome + ", sigla=" + sigla + ", codigo="
				+ codigo + ", ano=" + ano + ", semestre=" + semestre
				+ ", ativo=" + ativo + ", opcional=" + opcional
				+ ", ramo_nome=" + ramo_nome + ", ramo_id=" + ramo_id + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		Cadeira u=(Cadeira) obj;
		return (nome.equals(u.nome) && sigla==(u.sigla) && codigo==(u.codigo) );
	}
	
}
