import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import database.DBConnect;
import datatypes.Cadeira;
import datatypes.Curso;
import datatypes.Professor;


public class DBUpdater {

	private static final String dataFilePath = "data.json";
	private static final String configFilePath = "config.json";

	public static void main(String[] args) throws InterruptedException {			
		JSONParser jsonParser = new JSONParser();
		
		String DBUrl, DBname, DBUsername, DBPassword;
		
		try {
			
			InputStreamReader configReader = new InputStreamReader(new FileInputStream(configFilePath), "UTF-8");
			
			JSONObject databaseConfig = (JSONObject) jsonParser.parse(configReader);
			
			DBUrl = (String) databaseConfig.get("url");
			
			DBname = (String) databaseConfig.get("name");
			
			DBUsername = (String) databaseConfig.get("username");
			
			DBPassword = (String) databaseConfig.get("password");

			DBConnect connect = new DBConnect(DBUrl, DBname, DBUsername, DBPassword);
			
			//connect.getData();

			List<Curso> data = new ArrayList<Curso>();
			
			InputStreamReader dataReader = new InputStreamReader(new FileInputStream(dataFilePath), "UTF-8");

			JSONArray jsonArray = (JSONArray) jsonParser.parse(dataReader);

			for(int i=0; i<jsonArray.size(); i++){

				JSONObject cursoObj  = (JSONObject) jsonArray.get(i);

				Curso curso = new Curso();
				curso.nome = (String) cursoObj.get("nome");
				curso.sigla = (String) cursoObj.get("sigla");

				JSONArray cadeiras = (JSONArray) cursoObj.get("cadeiras");

				for(int j=0; j<cadeiras.size(); j++){
					JSONObject cadeiraObj  = (JSONObject) cadeiras.get(j);

					Cadeira cadeira = new Cadeira();

					cadeira.ano = (String) cadeiraObj.get("ano");
					cadeira.ativo = (String) cadeiraObj.get("ativo");
					cadeira.codigo = (String) cadeiraObj.get("codigo");
					cadeira.nome = (String) cadeiraObj.get("nome");
					cadeira.opcional = (String) cadeiraObj.get("opcional");

					JSONObject ramo  = (JSONObject) cadeiraObj.get("ramo");
					
					cadeira.ramo_nome = (String) ramo.get("nome");
					cadeira.ramo_id = (Long) ramo.get("id");

					cadeira.semestre = (String) cadeiraObj.get("semestre");
					cadeira.sigla = (String) cadeiraObj.get("sigla");
					
					JSONArray profs = (JSONArray) cadeiraObj.get("profs");

					for(int z=0; z<profs.size(); z++){
						JSONObject profObj  = (JSONObject) profs.get(z);

						Professor professor = new Professor();
						professor.nome = (String) profObj.get("nome");
						professor.codigo = (String) profObj.get("codigo");
						professor.foto = (String) profObj.get("foto");

						cadeira.profs.add(professor);
						//connect.updateProfessor(professor);
					}
					
					curso.cadeiras.add(cadeira);
				}
				
				data.add(curso);
				connect.updateCurso(curso);
			}

			//end of reading json data file

		} catch (IOException | ParseException ex) {
			System.out.println();
			ex.printStackTrace();
			System.exit(-1);
		}
		return;
	}
}
