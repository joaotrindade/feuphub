package database;

import java.sql.*;

import datatypes.Cadeira;
import datatypes.Curso;
import datatypes.Professor;

public class DBConnect {

	private Connection con;
	private Statement st;
	private ResultSet rs;

	private String dBname;
	public DBConnect(String dBUrl, String dBname, String dBUsername,String dBPassword) {
		try{
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://"+dBUrl+":3306/"+dBname,dBUsername,dBPassword);
			st = con.createStatement();
			this.dBname=dBname;
		}catch(Exception err){
			System.out.println("Error: "+err);
		}
	}

	public void getData(){
		try {

			String query = "SELECT * FROM `Curso`";
			rs = st.executeQuery(query);
			System.out.println("Records from database:");
			while(rs.next()){
				System.out.println("Nome: "+rs.getString("nome")+", sigla:"+rs.getString("sigla"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public boolean updateCurso(Curso curso){
		try {
			String query = "SELECT * FROM `Curso` where `sigla` ='"+curso.sigla+"'";
			rs = st.executeQuery(query);
			if(rs.next()){
				Curso dbCurso = new Curso(rs.getString("nome"),rs.getString("sigla"));
				if(dbCurso != curso){
					query = "UPDATE `"+this.dBname+"`.`Curso` SET `sigla` = '"+curso.sigla+"', `nome` = '"+curso.nome+"' WHERE `Curso`.`sigla` = '"+curso.sigla+"';";
					if(st.executeUpdate(query) == 0){
						System.out.println("updateCurso, failed to update row where column codigo is: "+curso.sigla);
					}
				}
			}
			else{
				query = "INSERT INTO `"+this.dBname+"`.`Curso` (`sigla`, `nome`) VALUES ('"+curso.sigla+"', '"+curso.nome+"');";
				if(st.executeUpdate(query) == 0){
					System.out.println("updateCurso, failed to update row where column codigo is: "+curso.sigla);
				}
			}
		} catch (Exception e) {
			System.out.println("Curso estourou: "+curso.toString());
			System.out.println(e);
		}

		for (Cadeira cadeira : curso.cadeiras) {
			updateCadeira(cadeira);
			//System.out.println("Done cadeira: "+cadeira.codigo);
			for(Professor prof : cadeira.profs){
				updateProfessor(prof);
				//System.out.println("Done prof: "+prof.codigo);
				updateCadeiraProfessor(cadeira,prof);
			}
			updatePercurso(cadeira);
			updateCadeiraCurso(curso,cadeira);
		}
		System.out.println("Done curso: "+curso.sigla);
		return true;
	}

	private void updateCadeira(Cadeira cadeira){
		try {
			String query = "SELECT * FROM `Cadeira` where `codigo` ='"+cadeira.codigo+"'";
			rs = st.executeQuery(query);
			if(rs.next()){
				Cadeira dbCadeira = new Cadeira(rs.getString("codigo"),rs.getString("nome"),rs.getString("sigla"));
				if(dbCadeira != cadeira){
					query = "UPDATE `"+this.dBname+"`.`Cadeira` SET `codigo` = '"+cadeira.codigo+"', `nome` = '"+cadeira.nome+"', `sigla` = '"+cadeira.sigla+"' WHERE `Cadeira`.`codigo` = '"+cadeira.codigo+"';";
					if(st.executeUpdate(query) == 0){
						System.out.println("updateCadeira, failed to update row where column codigo is: "+cadeira.codigo);
					}
				}
			}
			else{
				query = "INSERT INTO `"+this.dBname+"`.`Cadeira` (`codigo`,`nome`, `sigla`) VALUES ('"+cadeira.codigo+"', '"+cadeira.nome+"', '"+cadeira.sigla+"');";
				if(st.executeUpdate(query) == 0){
					System.out.println("updateCadeira, failed to update row where column codigo is: "+cadeira.codigo);
				}
			}

		} catch (Exception e) {
			System.out.println("Cadeira estourou:\n\t"+cadeira.toString());
			System.out.println(e);
		}
	}

	private void updateProfessor(Professor prof){
		try {
			String query = "SELECT * FROM `Docente` where `codigo` ='"+prof.codigo+"'";
			rs = st.executeQuery(query);
			if(rs.next()){
				//test diferences
				Professor dbProf = new Professor(rs.getString("codigo"),rs.getString("img_url"),rs.getString("nome"));
				if(dbProf != prof){
					query = "UPDATE `"+this.dBname+"`.`Docente` SET `codigo` = '"+prof.codigo+"', `nome` = '"+prof.nome+"', `img_url` = '"+prof.foto+"' WHERE `Docente`.`codigo` = '"+prof.codigo+"'";
					if(st.executeUpdate(query) == 0){
						System.out.println("updateProfessor, failed to update row where column codigo is: "+prof.codigo);
					}
				}
			}
			else{
				query = "INSERT INTO `"+this.dBname+"`.`Docente` (`codigo`, `nome`, `avaliacao`, `img_url`) VALUES ('"+prof.codigo+"', '"+prof.nome+"', '"+5.0+"', '"+prof.foto+"')";
				if(st.executeUpdate(query) == 0){
					System.out.println("updateProfessor, failed to insert row!");
				}
			}

		} catch (Exception e) {
			System.out.println("Prof estourou:\n\t"+prof.toString());
			System.out.println(e);
			System.out.println("\n");
		}
	}

	private void updateCadeiraProfessor(Cadeira cadeira, Professor prof) {
		try {
			String query = "SELECT * FROM `CadeiraDocente` where `CadeiraKey` = '"+cadeira.codigo+"' AND `DocenteKey` = '"+prof.codigo+"'";
			rs = st.executeQuery(query);
			if(rs.next()){} //do nothing, no update necessary
			else{
				query = "INSERT INTO `"+this.dBname+"`.`CadeiraDocente` (`CadeiraKey`, `DocenteKey`) VALUES ('"+cadeira.codigo+"', '"+prof.codigo+"')";
				if(st.executeUpdate(query) == 0){
					System.out.println("updateCadeiraProfessor, failed to insert row!"+cadeira.codigo+" "+prof.codigo);
				}
			}

		} catch (Exception e) {
			System.out.println("CadeiraProf estourou:\n\t"+cadeira.codigo+"\n\t"+prof.codigo);
			System.out.println(e);
		}		
	}

	private void updatePercurso(Cadeira cadeira) {
		try {
			String query = "SELECT * FROM `Percurso` where `id` = '"+cadeira.ramo_id+"'";
			rs = st.executeQuery(query);
			if(rs.next()){} //do nothing, no need to update
			else{
				query = "INSERT INTO `"+this.dBname+"`.`Percurso` (`id`,`nome`) VALUES ('"+cadeira.ramo_id+"', '"+cadeira.ramo_nome+"');";
				if(st.executeUpdate(query) == 0){
					System.out.println("updatePercurso, failed to insert row! "+cadeira.ramo_id +" "+cadeira.ramo_nome);
				}
			}
		} catch (Exception e) {
			System.out.println("Percurso estourou:\n\t"+cadeira.toString());
			System.out.println(e);
		}	

	}

	private void updateCadeiraCurso(Curso curso, Cadeira cadeira) {
		try {
			String query = "SELECT * FROM CadeiraCurso where CadeiraKey = '"+cadeira.codigo+"' AND CursoKey = '"+curso.sigla+"';";
			rs = st.executeQuery(query);
			if(rs.next()){
				
				if(!rs.getString("ano").equals(cadeira.ano) || !rs.getString("semestre").equals(cadeira.semestre) || !rs.getString("ativo").equals(cadeira.ativo)|| !rs.getString("opcional").equals(cadeira.opcional) || Long.valueOf(rs.getString("PercursoKey")).longValue()!=cadeira.ramo_id)
				{/*
					if(!rs.getString("ano").equals(cadeira.ano)){
						System.out.print("ano: "); System.out.println(rs.getString("ano")+" vs "+cadeira.ano);
					}

					if(!rs.getString("semestre").equals(cadeira.semestre)){
						System.out.print("semestre: "); System.out.println(rs.getString("semestre")+" vs "+cadeira.semestre);
					}

					if(!rs.getString("ativo").equals(cadeira.ativo)){
						System.out.print("ativo: "); System.out.println(rs.getString("ativo")+" vs "+cadeira.ativo);
					}

					if(!rs.getString("opcional").equals(cadeira.opcional)){
						System.out.print("opcional: "); System.out.println(rs.getString("opcional")+" vs "+cadeira.opcional);
					}

					if(Long.valueOf(rs.getString("PercursoKey")).longValue()!=cadeira.ramo_id){
						System.out.print("PercursoKey: "); System.out.println(rs.getString("PercursoKey")+" vs "+cadeira.ramo_id);
					}
*/
					query = "UPDATE `"+this.dBname+"`.`CadeiraCurso` SET `ano` = '"+cadeira.ano+"', `semestre` = '"+cadeira.semestre+"', `ativo` = '"+cadeira.ativo.toString()+"', `opcional` = '"+cadeira.opcional.toString()+"', `PercursoKey` = '"+cadeira.ramo_id+"' WHERE `CadeiraCurso`.`CadeiraKey` = '"+cadeira.codigo+"' AND `CadeiraCurso`.`CursoKey` = '"+curso.sigla+"';";
					if(st.executeUpdate(query) == 0){
						System.out.println("updateCadeiraCurso, failed to update row where column codigo is: "+cadeira.codigo+" e "+curso.sigla);
					}
				}
			}
			else{
				query = "INSERT INTO `"+this.dBname+"`.`CadeiraCurso` (`CadeiraKey`, `CursoKey`, `ano`, `semestre`, `ativo`, `opcional`, `PercursoKey`) VALUES ('"+
						cadeira.codigo+"', '"+
						curso.sigla+"', '"+
						cadeira.ano+"', '"+
						cadeira.semestre+"', '"+
						cadeira.ativo.toString()+"', '"+
						cadeira.opcional.toString()+"', '"+
						cadeira.ramo_id+"');";
				if(st.executeUpdate(query) == 0){
					System.out.println("updateCadeiraCurso, failed to insert row! "+cadeira.codigo +" e "+curso.sigla);
				}

			}
		} catch (Exception e) {
			System.out.println("CadeiraCurso estourou:\n\t"+curso.toString()+"\n\t"+cadeira.toString());
			System.out.println(e);
		}	
	}
}
